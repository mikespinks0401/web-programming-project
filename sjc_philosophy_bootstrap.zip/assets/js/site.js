(function () {
  const root = document.documentElement;
  const storedTheme = localStorage.getItem('sjc-theme');
  const initialTheme = storedTheme || 'light';

  function applyTheme(theme) {
    root.setAttribute('data-bs-theme', theme);
    document.querySelectorAll('[data-theme-toggle]').forEach(function (toggle) {
      toggle.checked = theme === 'dark';
      toggle.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    });
    document.querySelectorAll('[data-theme-label]').forEach(function (label) {
      label.textContent = theme === 'dark' ? 'Dark mode' : 'Light mode';
    });
  }

  applyTheme(initialTheme);

  document.addEventListener('change', function (event) {
    if (!event.target.matches('[data-theme-toggle]')) return;
    const theme = event.target.checked ? 'dark' : 'light';
    localStorage.setItem('sjc-theme', theme);
    applyTheme(theme);
  });

  const thinkers = document.querySelectorAll('[data-thinker-button]');
  const spotlightImage = document.querySelector('[data-thinker-image]');
  const spotlightTitle = document.querySelector('[data-thinker-title]');
  const spotlightCopy = document.querySelector('[data-thinker-copy]');

  if (thinkers.length && spotlightImage && spotlightTitle && spotlightCopy) {
    thinkers.forEach(function (button) {
      button.addEventListener('click', function () {
        thinkers.forEach(function (item) { item.classList.remove('active'); });
        button.classList.add('active');
        spotlightImage.src = button.dataset.image;
        spotlightImage.alt = button.dataset.alt;
        spotlightTitle.textContent = button.dataset.title;
        spotlightCopy.textContent = button.dataset.copy;
      });
    });
  }
})();
